"""Security Auditor (`sec`)."""
