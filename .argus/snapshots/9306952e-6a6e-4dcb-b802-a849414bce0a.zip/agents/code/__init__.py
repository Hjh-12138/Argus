"""Code Auditor (`code`)."""
