"""Dependency Auditor (`dep`)."""
