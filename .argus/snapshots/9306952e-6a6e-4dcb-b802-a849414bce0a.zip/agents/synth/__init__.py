"""Audit Synthesizer (`synth`)."""
