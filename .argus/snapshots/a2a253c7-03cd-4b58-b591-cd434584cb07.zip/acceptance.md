# Argus Phase-One Acceptance

- Run: `20260808-163333-d1a2fd`
- Phase one: `rejected`
- Accepted: ``
- Generated: `2026-08-08T16:53:43.882409+00:00Z`

## Items

- **A1** PASS: vulnerable demo blocked with all three categories
- **A2** FAIL: demo agentteams audit did not complete on real Workers
- **A3** PASS: fixed demo passed with no vulnerable categories
- **A4** FAIL: koubo agentteams audit did not complete on real Workers
- **A5** FAIL: argus-meta: ready=[] want=['argus-evidence-verify']; argus-synth: ready=[] want=['argus-release-policy-evaluate', 'argus-report-materialize']
- **A6** FAIL: local suite failed: 0 passed, 0 failed, 0 skipped, 0 deselected
- **A7** PASS: random canary zero leak across report and audit output
- **A8** PASS: README/简介/PPT/acceptance.md match measured facts
